# مەیدانی جەنگ — Multiplayer prototype

This is an early browser multiplayer networking test, not a finished battle-royale game.

## What it currently does
- Browser client for iPhone, Android and desktop.
- WebSocket server with shared rooms.
- Players in the same room see each other's positions live.
- Prototype cap: 10 players per room.

## What it does NOT do
- It is not a 100-player stress-tested server.
- No authoritative shooting, damage, loot, vehicles, parachute, anti-cheat or PUBG-scale map yet.
- Free hosting is for testing only and may sleep, restart or impose limits.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000` on a browser.

## Deploy for a free test
Render supports free web services and WebSockets, but free services sleep after 15 minutes without traffic and may take about a minute to wake. They are not production hosting.
1. Upload this folder to a GitHub repository.
2. In Render choose New > Web Service and connect the repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Choose Free instance and deploy.
6. Open the Render URL on two different devices, enter the same room code and join.

Do not enter payment details or upgrade just to test. Stop if a platform asks for a paid plan.
