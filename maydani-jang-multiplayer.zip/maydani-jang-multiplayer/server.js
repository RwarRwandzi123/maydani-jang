import http from "node:http";
import { readFile } from "node:fs/promises";
import { WebSocketServer } from "ws";
import { randomUUID } from "node:crypto";

const PORT = process.env.PORT || 3000;
const MAX_PLAYERS_PER_ROOM = 10; // Prototype cap; do not claim 100-player capacity.
const players = new Map();
const rooms = new Map();

const server = http.createServer(async (req, res) => {
  const path = req.url === "/" ? "/index.html" : req.url;
  try {
    const data = await readFile(new URL("./public" + path, import.meta.url));
    res.writeHead(200, { "Content-Type": path.endsWith(".js") ? "text/javascript" : "text/html" });
    res.end(data);
  } catch {
    res.writeHead(404); res.end("Not found");
  }
});

const wss = new WebSocketServer({ server });
function send(ws, obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); }
function snapshot(room) {
  return [...players.values()].filter(p => p.room === room).map(({id,name,x,z,yaw}) => ({id,name,x,z,yaw}));
}
function broadcast(room) {
  const state = { type:"state", players:snapshot(room) };
  for (const p of players.values()) if (p.room === room) send(p.ws, state);
}
function leave(ws) {
  const p = players.get(ws.id);
  if (!p) return;
  const room = p.room;
  players.delete(p.id);
  if (room) broadcast(room);
}

wss.on("connection", ws => {
  ws.id = randomUUID();
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "join") {
      const room = String(msg.room || "ERBIL-01").toUpperCase().replace(/[^A-Z0-9-]/g,"").slice(0,16);
      const members = [...players.values()].filter(p => p.room === room);
      if (members.length >= MAX_PLAYERS_PER_ROOM) {
        send(ws, {type:"error", message:`ئەم ژوورە پڕە (سنووری تاقیکردنەوە ${MAX_PLAYERS_PER_ROOM} یاریزانە).`});
        return;
      }
      const p = {
        id: ws.id, ws, room,
        name: String(msg.name || "Player").slice(0,16),
        x: (Math.random()-.5)*12, z: (Math.random()-.5)*12, yaw: 0
      };
      players.set(p.id,p);
      send(ws,{type:"welcome",id:p.id,room,cap:MAX_PLAYERS_PER_ROOM});
      broadcast(room);
      return;
    }

    const p = players.get(ws.id);
    if (!p || !p.room) return;
    if (msg.type === "move") {
      p.x = Math.max(-40,Math.min(40,Number(msg.x)||0));
      p.z = Math.max(-40,Math.min(40,Number(msg.z)||0));
      p.yaw = Number(msg.yaw)||0;
      broadcast(p.room);
    }
    if (msg.type === "ping") send(ws,{type:"pong",at:msg.at});
  });
  ws.on("close",()=>leave(ws));
  ws.on("error",()=>leave(ws));
});

server.listen(PORT,()=>console.log(`Maydani Jang test server listening on ${PORT}`));
